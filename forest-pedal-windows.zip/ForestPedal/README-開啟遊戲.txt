森森騎旅 — 電腦版

適用 Windows 10/11 64 位元。已附官方 Node.js 執行程式，
Windows 不需要安裝 Node.js，也不需要輸入指令。
Mac/Linux 仍需先安裝 Node.js LTS：https://nodejs.org/zh-tw/download

一、對 ZIP 按右鍵，選「全部解壓縮」。不要在壓縮檔內直接執行。

二、打開解壓縮後的 ForestPedal 資料夾，點兩下啟動檔：
Windows：start-windows.cmd
Mac：start-macos.command
Linux：在終端機執行 ./start-linux.sh

啟動後會自動開啟瀏覽器。終端機視窗請保持開啟。
如果瀏覽器沒有自動開啟，請複製終端機顯示的網址，
在同一台電腦的 Chrome 或 Edge 開啟。

Mac 若提示無法執行 .command，可在終端機切到本資料夾，
執行 node server.cjs 即可。

三、先點「開始騎行」試玩。要實際踩踏，點「使用攝影機」，
允許攝影機權限，將肩膀、髖部、膝蓋和雙腳完整拍進畫面。
坐穩後交替抬腿，持續踩數圈，遊戲便會依節奏加速。
影像只在你的電腦分析，不錄影、不上傳。

四、結束遊戲時，關閉黑色終端機視窗。

備註：這是本機電腦版，網址只供啟動遊戲的這台電腦使用。
不要直接點 app/index.html，也不要將終端機的網址傳給別人。
不同啟動埠會使用不同的瀏覽器紀錄空間。
模型授權與來源在 app/pose/LICENSE 與 provenance.json。
Windows 執行程式授權與來源在 runtime/ 資料夾。
