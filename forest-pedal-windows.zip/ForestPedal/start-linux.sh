#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "請先安裝 Node.js LTS：https://nodejs.org/zh-tw/download"
  printf "安裝完成後，重新開啟啟動檔。按 Enter 關閉。"
  read -r reply
  exit 1
fi
node "./server.cjs"
