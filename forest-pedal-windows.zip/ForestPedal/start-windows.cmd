@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0runtime\node.exe" (
  "%~dp0runtime\node.exe" "%~dp0server.cjs"
  goto end
)
where node >nul 2>nul
if errorlevel 1 (
  echo 請先安裝 Node.js LTS，再重新開啟此檔案。
  echo 下載網址：https://nodejs.org/zh-tw/download
  pause
  exit /b 1
)
node "%~dp0server.cjs"
:end
pause
